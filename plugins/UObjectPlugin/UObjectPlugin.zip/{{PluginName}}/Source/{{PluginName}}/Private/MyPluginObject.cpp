// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "{{PluginName}}PrivatePCH.h"
#include "MyPluginObject.h"


UMyPluginObject::UMyPluginObject( const FObjectInitializer& ObjectInitializer )
	: Super( ObjectInitializer )
{
}