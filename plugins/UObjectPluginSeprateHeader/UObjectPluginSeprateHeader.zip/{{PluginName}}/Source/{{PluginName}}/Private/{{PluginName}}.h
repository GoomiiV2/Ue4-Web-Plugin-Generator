// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "{{PluginName}}PrivatePCH.h"

class F{{PluginName}} : public I{{PluginName}}
{
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};



