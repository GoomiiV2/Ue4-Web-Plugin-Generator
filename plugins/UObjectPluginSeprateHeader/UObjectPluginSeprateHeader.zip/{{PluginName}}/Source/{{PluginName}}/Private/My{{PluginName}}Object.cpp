// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "{{PluginName}}PrivatePCH.h"
#include "My{{PluginName}}Object.h"


UMy{{PluginName}}Object::UMy{{PluginName}}Object(const FObjectInitializer& ObjectInitializer)
	: Super( ObjectInitializer )
{
}