// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "My{{PluginName}}Object.generated.h"


/**
 * Example UStruct declared in a plugin module
 */
USTRUCT()
struct FMy{{PluginName}}Struct
{
	GENERATED_USTRUCT_BODY()
 
	UPROPERTY()
	FString TestString;
};
 

/**
 * Example of declaring a UObject in a plugin module
 */
UCLASS()
class UMy{{PluginName}}Object : public UObject
{
	GENERATED_BODY()

public:
	UMy{{PluginName}}Object(const FObjectInitializer& ObjectInitializer);

private:

	UPROPERTY()
	FMy{{PluginName}}Struct MyStruct;

};


